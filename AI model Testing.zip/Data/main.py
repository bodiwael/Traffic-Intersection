import cv2
import time
from collections import defaultdict
from ultralytics import YOLO
import firebase_admin
from firebase_admin import credentials, db

# --- CONFIGURATION ---
MODEL_PATH = "best.pt"
FIREBASE_CREDENTIALS_PATH = "google-services.json"
FIREBASE_DATABASE_URL = "https://stem-53cdc-default-rtdb.firebaseio.com/"

# Settings
CONFIDENCE_THRESHOLD = 0.4
FRAME_SKIP = 5
EMERGENCY_CLASS_NAME = "ambulance"  # Ensure this matches your dataset label exactly
EMERGENCY_EXIT_DELAY = 10  # Seconds to wait after emergency vehicle leaves

def init_firebase():
    """Initialize Firebase connection"""
    try:
        cred = credentials.Certificate(FIREBASE_CREDENTIALS_PATH)
        firebase_admin.initialize_app(cred, {'databaseURL': FIREBASE_DATABASE_URL})
        print("✓ Firebase connected")
        return True
    except Exception as e:
        print(f"✗ Firebase error: {e}")
        return False

def control_hardware_firebase(state_type):
    """
    Controls ESP32 based on the high-level state.
    state_type options: 'EMERGENCY', 'CONGESTED', 'CLEAR'
    """
    try:
        updates = {}
        
        if state_type == 'EMERGENCY':
            # Gate Open (Pin 2 HIGH), Red Light for others ("100")
            updates['/lane_light'] = 1  
            updates['/traffic_lights'] = "100"
            
        elif state_type == 'CONGESTED':
            # Gate Open (Pin 2 HIGH), Green Light for traffic ("001")
            updates['/lane_light'] = 1
            updates['/traffic_lights'] = "001"
            
        else: # CLEAR
            # Gate Closed (Pin 2 LOW), Red Light ("100")
            updates['/lane_light'] = 0
            updates['/traffic_lights'] = "100"

        db.reference().update(updates)
        return True
    except Exception as e:
        print(f"✗ Hardware control error: {e}")
        return False

def draw_detections(frame, predictions, roi_offset=(0,0)):
    """Draw boxes on the main frame, adjusting for ROI offset"""
    off_x, off_y = roi_offset
    
    for pred in predictions:
        # Adjust coordinates back to full frame
        x = int(pred['x'] + off_x - pred['width'] / 2)
        y = int(pred['y'] + off_y - pred['height'] / 2)
        w = int(pred['width'])
        h = int(pred['height'])
        
        # Color: Red for Ambulance, Green for Car
        if pred['class'] == EMERGENCY_CLASS_NAME:
            color = (0, 0, 255)
        elif pred['class'] == 'car':
            color = (0, 255, 0)
        else:
            color = (255, 0, 255)
        
        cv2.rectangle(frame, (x, y), (x + w, y + h), color, 2)
        
        label = f"{pred['class']}: {pred['confidence']:.2f}"
        cv2.rectangle(frame, (x, y - 25), (x + len(label) * 12, y), color, -1)
        cv2.putText(frame, label, (x + 5, y - 7), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 2)
    return frame

def draw_status_panel(frame, car_count, fps, status, timer_val=0):
    """Draws a status dashboard on the frame"""
    overlay = frame.copy()
    cv2.rectangle(overlay, (10, 10), (450, 220), (0, 0, 0), -1)
    cv2.addWeighted(overlay, 0.7, frame, 0.3, 0, frame)
    
    y = 40
    cv2.putText(frame, f"FPS: {fps:.1f}", (20, y), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    y += 35
    cv2.putText(frame, f"Cars in ROI: {car_count}", (20, y), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    
    y += 40
    # Dynamic Status Color
    if "EMERGENCY" in status:
        color = (0, 0, 255) # Red
    elif "CONGESTED" in status:
        color = (0, 255, 255) # Yellow
    else:
        color = (0, 255, 0) # Green
        
    cv2.putText(frame, f"STATUS: {status}", (20, y), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
    
    if timer_val > 0:
        y += 35
        cv2.putText(frame, f"Closing in: {timer_val:.1f}s", (20, y), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)

    return frame

def main():
    print("="*70)
    print("TRAFFIC CONTROL: ROI + SMART EMERGENCY TIMER")
    print("="*70)
    
    if not init_firebase(): return
    
    try:
        model = YOLO(MODEL_PATH)
        print("✓ Model loaded")
    except Exception as e:
        print(f"✗ Model error: {e}")
        return

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("✗ Webcam error")
        return

    # --- STEP 1: ROI SELECTION ---
    print("\nSelect the road area (ROI) and press ENTER or SPACE.")
    ret, first_frame = cap.read()
    if ret:
        first_frame = cv2.resize(first_frame, (640, 480))
        # This opens a window to select the box
        roi = cv2.selectROI("Select Detection Area", first_frame, fromCenter=False, showCrosshair=True)
        cv2.destroyWindow("Select Detection Area")
        
        # roi returns (x, y, w, h). If user cancels, it returns (0,0,0,0)
        roi_x, roi_y, roi_w, roi_h = roi
        if roi_w == 0 or roi_h == 0:
            print("No area selected. Using full frame.")
            roi_x, roi_y, roi_w, roi_h = 0, 0, 640, 480
    else:
        print("Could not read frame for ROI selection.")
        return

    print(f"✓ Monitoring Area: x={roi_x}, y={roi_y}, w={roi_w}, h={roi_h}")

    # --- VARIABLES ---
    frame_count = 0
    fps_time = time.time()
    fps_counter = 0
    current_fps = 0
    
    # Emergency Logic Variables
    emergency_active = False
    last_emergency_seen_time = 0
    
    # To prevent flooding Firebase
    last_sent_status = ""
    last_firebase_update = 0
    FIREBASE_UPDATE_INTERVAL = 1.0 # Update every 1 second max

    try:
        while True:
            ret, frame = cap.read()
            if not ret: break
            
            frame = cv2.resize(frame, (640, 480))
            
            # Draw the ROI box so user sees what is being monitored
            cv2.rectangle(frame, (roi_x, roi_y), (roi_x + roi_w, roi_y + roi_h), (255, 0, 0), 2)
            
            frame_count += 1
            fps_counter += 1
            if time.time() - fps_time >= 1.0:
                current_fps = fps_counter / (time.time() - fps_time)
                fps_counter = 0
                fps_time = time.time()

            predictions = []
            car_count = 0
            
            # --- DETECTION LOGIC ---
            if frame_count % FRAME_SKIP == 0:
                # 1. Crop the frame to the ROI
                roi_frame = frame[roi_y:roi_y+roi_h, roi_x:roi_x+roi_w]
                
                # 2. Run Inference on CROPPED frame
                results = model(roi_frame, conf=CONFIDENCE_THRESHOLD, verbose=False)[0]
                
                class_counts = defaultdict(int)
                
                for box in results.boxes:
                    # Coords are relative to the ROI crop
                    bx, by, bw, bh = box.xywh[0].tolist()
                    cls_id = int(box.cls[0])
                    class_name = model.names[cls_id]
                    conf = float(box.conf[0])
                    
                    predictions.append({
                        'x': bx, 'y': by, 'width': bw, 'height': bh,
                        'class': class_name, 'confidence': conf
                    })
                    class_counts[class_name] += 1
                
                car_count = class_counts.get('car', 0)
                emergency_present_now = class_counts.get(EMERGENCY_CLASS_NAME, 0) > 0

                # --- DECISION LOGIC (STATE MACHINE) ---
                current_time = time.time()
                current_status = "CLEAR"
                timer_display = 0

                # Case A: Emergency is currently in the frame
                if emergency_present_now:
                    emergency_active = True
                    last_emergency_seen_time = current_time
                    current_status = "EMERGENCY"
                
                # Case B: Emergency was recently seen (Wait 10s)
                elif emergency_active:
                    time_since_exit = current_time - last_emergency_seen_time
                    
                    if time_since_exit < EMERGENCY_EXIT_DELAY:
                        # Still waiting...
                        current_status = "EMERGENCY (WAITING)"
                        timer_display = EMERGENCY_EXIT_DELAY - time_since_exit
                    else:
                        # Time is up!
                        emergency_active = False
                        # Re-evaluate normal traffic immediately
                        if car_count >= 11:
                            current_status = "CONGESTED"
                        else:
                            current_status = "CLEAR"
                
                # Case C: Normal Traffic
                else:
                    if car_count >= 11:
                        current_status = "CONGESTED"
                    else:
                        current_status = "CLEAR"

                # --- FIREBASE UPDATE ---
                # Only update if status changes OR it's been a while (heartbeat)
                # But for safety, we send Emergency commands more aggressively
                if current_status != last_sent_status or (current_time - last_firebase_update > FIREBASE_UPDATE_INTERVAL):
                    
                    # Map internal status to hardware command
                    if "EMERGENCY" in current_status:
                        control_hardware_firebase("EMERGENCY")
                    elif "CONGESTED" in current_status:
                        control_hardware_firebase("CONGESTED")
                    else:
                        control_hardware_firebase("CLEAR")
                        
                    last_sent_status = current_status
                    last_firebase_update = current_time

            # --- DRAWING ---
            # Pass ROI offset so boxes draw in correct place on main frame
            frame = draw_detections(frame, predictions, roi_offset=(roi_x, roi_y))
            frame = draw_status_panel(frame, car_count, current_fps, last_sent_status, timer_display)
            
            cv2.imshow('Smart Traffic Control', frame)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'): break
            
    finally:
        cap.release()
        cv2.destroyAllWindows()
        print("✓ System Shutdown")

if __name__ == "__main__":
    main()